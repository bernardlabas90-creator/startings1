// Infobip Africa Banking Demo Application

// Application Data
const applicationData = {
  countries: {
    nigeria: {
      name: "Nigeria",
      flag: "🇳🇬",
      population: "218M",
      whatsappPenetration: "95.1%",
      mobilePenetration: "92%",
      smartphoneAdoption: "45%",
      bankingDigitalization: "41%",
      internetPenetration: "51%",
      mobileMoneyUsers: "51M",
      avgMonthlySalary: "₦120,000",
      keyPlayers: ["GTBank", "Access Bank", "First Bank", "UBA", "Zenith Bank"],
      challenges: ["Low financial inclusion (36%)", "High customer acquisition cost", "Regulatory compliance"],
      opportunities: ["Mobile money growth (+15% YoY)", "Digital payments surge", "Youth demographics (60% under 25)"],
      preferredChannels: ["WhatsApp", "SMS", "USSD"],
      bankingStats: {
        accountOwnership: "45%",
        mobileAppUsers: "78%",
        whatsappBankingAdoption: "23%",
        trustInDigitalBanking: "Medium"
      }
    },
    kenya: {
      name: "Kenya",
      flag: "🇰🇪",
      population: "56M",
      whatsappPenetration: "97%",
      mobilePenetration: "97%", 
      smartphoneAdoption: "58%",
      bankingDigitalization: "78%",
      internetPenetration: "87%",
      mobileMoneyUsers: "32M",
      avgMonthlySalary: "KSh 65,000",
      keyPlayers: ["Safaricom M-Pesa", "Equity Bank", "KCB Bank", "Absa Kenya", "Co-op Bank"],
      challenges: ["Market saturation", "Fintech competition", "Regulatory changes"],
      opportunities: ["M-Pesa ecosystem expansion", "Digital lending growth", "Rural market penetration"],
      preferredChannels: ["M-Pesa", "WhatsApp", "SMS"],
      bankingStats: {
        accountOwnership: "82%",
        mobileAppUsers: "89%",
        whatsappBankingAdoption: "45%",
        trustInDigitalBanking: "High"
      }
    },
    southAfrica: {
      name: "South Africa",
      flag: "🇿🇦",
      population: "60M",
      whatsappPenetration: "96%",
      mobilePenetration: "96%",
      smartphoneAdoption: "71%",
      bankingDigitalization: "85%",
      internetPenetration: "70%",
      mobileMoneyUsers: "15M",
      avgMonthlySalary: "R 23,000",
      keyPlayers: ["Standard Bank", "FNB", "Absa", "Nedbank", "Capitec"],
      challenges: ["Economic instability", "High inequality", "Load shedding impact"],
      opportunities: ["Open banking initiatives", "AI adoption", "Cross-border payments"],
      preferredChannels: ["Mobile Apps", "WhatsApp", "SMS"],
      bankingStats: {
        accountOwnership: "85%",
        mobileAppUsers: "91%",
        whatsappBankingAdoption: "67%",
        trustInDigitalBanking: "High"
      }
    },
    ghana: {
      name: "Ghana",
      flag: "🇬🇭",
      population: "33M",
      whatsappPenetration: "89%",
      mobilePenetration: "95%",
      smartphoneAdoption: "48%",
      bankingDigitalization: "58%",
      internetPenetration: "68%",
      mobileMoneyUsers: "18M",
      avgMonthlySalary: "GH₵ 2,800",
      keyPlayers: ["MTN MoMo", "Vodafone Cash", "GCB Bank", "Ecobank", "Access Bank Ghana"],
      challenges: ["Infrastructure gaps", "Power supply issues", "Digital literacy"],
      opportunities: ["Mobile money leadership", "Cross-border payments", "Digital government services"],
      preferredChannels: ["Mobile Money", "WhatsApp", "SMS"],
      bankingStats: {
        accountOwnership: "58%",
        mobileAppUsers: "72%",
        whatsappBankingAdoption: "34%",
        trustInDigitalBanking: "Medium"
      }
    }
  },
  
  bankingScenarios: [
    {
      id: "account-reactivation",
      title: "Account Reactivation Campaign",
      description: "Reactivate dormant customers with personalized offers",
      bank: "Access Bank Nigeria",
      avatar: "🏦",
      metrics: {
        conversionRate: "28%",
        avgCAC: "₦1,850",
        roi: "340%",
        avgResponseTime: "2.3 hours"
      },
      journey: [
        {
          step: 1,
          type: "outgoing",
          message: "Hi John! 👋 We noticed you haven't used your Access Bank account lately. We've enhanced our services with exciting benefits just for you! Would you like to see what you're missing?",
          options: ["Show Me Benefits", "Not Interested", "Call Me Later", "Unsubscribe"],
          dataCollected: {
            lastActivity: "127 days ago",
            accountBalance: "₦45,230",
            customerSegment: "Warm Lead",
            preferredChannel: "WhatsApp",
            creditScore: "Good",
            accountType: "Savings"
          }
        },
        {
          step: 2,
          type: "outgoing",
          message: "Excellent choice! 🎉 Here's what you're missing out on:\n\n💳 2% Cashback on ALL purchases\n📱 Mobile banking rewards program\n🎁 Exclusive member-only offers\n💰 4.5% savings account interest rate\n🌟 Priority customer support\n\nWhich benefit interests you most?",
          options: ["Cashback Program", "Savings Interest", "Mobile Rewards", "All Benefits"],
          dataCollected: {
            engagementScore: "75/100",
            interestLevel: "High",
            conversionProbability: "68%",
            timeOnPage: "45 seconds"
          }
        },
        {
          step: 3,
          type: "outgoing",
          message: "Perfect! Our cashback program is amazing:\n\n✨ 2% cashback on all purchases\n⛽ 5% cashback on fuel\n🛒 5% cashback on groceries\n🍽️ 10% cashback on dining\n🎯 Bonus points for every transaction\n\nYou'll get instant notifications and monthly summaries. Ready to reactivate your account and start earning?",
          options: ["Yes, Reactivate Now!", "More Details", "Speak to Agent", "Send Information"],
          dataCollected: {
            engagementScore: "95/100",
            interestLevel: "Very High",
            conversionProbability: "85%",
            nextBestAction: "Account Reactivation"
          }
        }
      ]
    },
    {
      id: "loan-application",
      title: "Digital Loan Application",
      description: "Complete loan application process via WhatsApp",
      bank: "First Bank Nigeria",
      avatar: "💳",
      metrics: {
        conversionRate: "85%",
        avgProcessingTime: "5 minutes",
        approvalRate: "72%",
        customerSatisfaction: "4.8/5"
      },
      journey: [
        {
          step: 1,
          type: "outgoing",
          message: "Hello! 🏦 Welcome to First Bank's instant loan service. I can help you get pre-approved for a personal loan in under 5 minutes. Let's check your eligibility first!",
          options: ["Check Eligibility", "Learn More", "Speak to Advisor", "View Requirements"],
          dataCollected: {
            eligibilityScore: "Good",
            creditRating: "720",
            existingCustomer: "Yes",
            monthlyIncome: "₦180,000",
            employmentStatus: "Full-time"
          }
        },
        {
          step: 2,
          type: "outgoing",
          message: "Great news! 🎉 You're pre-qualified for a loan:\n\n📊 Pre-approval amount: Up to ₦500,000\n💰 Interest rate: 12% APR\n📅 Flexible terms: 6-24 months\n⚡ Processing time: 24 hours\n✅ Your profile looks excellent!\n\nHow much would you like to borrow?",
          options: ["₦100,000", "₦250,000", "₦500,000", "Custom Amount"],
          dataCollected: {
            preApprovalAmount: "₦500,000",
            interestRate: "12% APR",
            creditCheck: "Passed",
            riskCategory: "Low"
          }
        },
        {
          step: 3,
          type: "outgoing",
          message: "Perfect choice! Here's your loan summary:\n\n💰 Loan Amount: ₦250,000\n📅 Term: 12 months\n💳 Monthly Payment: ₦23,456\n📈 Interest Rate: 12% APR\n⏰ Funds available: Within 24 hours\n📋 No hidden fees\n\nShall we proceed with the application?",
          options: ["Accept & Apply", "Change Terms", "Download Contract", "Speak to Agent"],
          dataCollected: {
            loanAmount: "₦250,000",
            monthlyPayment: "₦23,456",
            termLength: "12 months",
            approvalStatus: "Pre-approved"
          }
        }
      ]
    },
    {
      id: "mobile-money-transfer",
      title: "Mobile Money Transfer",
      description: "Send money across Africa instantly",
      bank: "Equity Bank Kenya",
      avatar: "📲",
      metrics: {
        conversionRate: "92%",
        avgTransactionTime: "30 seconds",
        successRate: "99.2%",
        customerSatisfaction: "4.9/5"
      },
      journey: [
        {
          step: 1,
          type: "outgoing",
          message: "Habari Grace! 👋 Welcome to Equity Mobile. I can help you send money instantly across Kenya and East Africa. What would you like to do today?",
          options: ["Send Money", "Check Balance", "Transaction History", "Pay Bills"],
          dataCollected: {
            customerType: "Premium",
            accountBalance: "KSh 125,450",
            lastTransaction: "2 hours ago",
            loyaltyTier: "Gold"
          }
        },
        {
          step: 2,
          type: "outgoing",
          message: "Excellent! I'll help you send money safely and instantly. 💸\n\nPlease provide:\n📱 Recipient's phone number\n💰 Amount to send\n🌍 Destination country\n\nOr choose a recent recipient:",
          options: ["+254712345678 - Mary K.", "+256701234567 - James M.", "New Recipient", "International Transfer"],
          dataCollected: {
            availableBalance: "KSh 125,450",
            dailyLimit: "KSh 150,000",
            transactionFee: "KSh 25",
            exchangeRate: "Current"
          }
        },
        {
          step: 3,
          type: "outgoing",
          message: "Perfect! Here are your transfer details:\n\n👤 To: Mary Kamau (+254712345678)\n💰 Amount: KSh 5,000\n💳 Fee: KSh 25\n📍 Network: M-Pesa\n⚡ Delivery: Instant\n🔒 Secure & encrypted\n\nTotal: KSh 5,025\nConfirm transfer?",
          options: ["Confirm & Send", "Edit Details", "Save Template", "Cancel"],
          dataCollected: {
            recipient: "Mary Kamau",
            amount: "KSh 5,000",
            totalCost: "KSh 5,025",
            deliveryTime: "Instant",
            transactionId: "Generated"
          }
        }
      ]
    }
  ]
};

// Application State
class AppState {
  constructor() {
    this.selectedCountry = null;
    this.selectedProducts = new Set();
    this.selectedChannels = new Set(['whatsapp', 'sms']);
    this.currentSection = 'landing';
    this.currentScenario = 'account-reactivation';
    this.currentStep = 0;
    this.chatMessages = [];
    this.analyticsData = {};
    this.progressStep = 1;
  }

  selectCountry(countryKey) {
    this.selectedCountry = countryKey;
    this.updateProgress(2);
  }

  toggleProduct(productKey) {
    if (this.selectedProducts.has(productKey)) {
      this.selectedProducts.delete(productKey);
    } else {
      this.selectedProducts.add(productKey);
    }
  }

  toggleChannel(channelKey) {
    if (this.selectedChannels.has(channelKey)) {
      this.selectedChannels.delete(channelKey);
    } else {
      this.selectedChannels.add(channelKey);
    }
  }

  updateProgress(step) {
    this.progressStep = step;
    this.updateProgressIndicator();
  }

  updateProgressIndicator() {
    const steps = document.querySelectorAll('.progress-step');
    steps.forEach((step, index) => {
      step.classList.remove('active', 'completed');
      if (index + 1 < this.progressStep) {
        step.classList.add('completed');
      } else if (index + 1 === this.progressStep) {
        step.classList.add('active');
      }
    });
  }
}

// Initialize application state
const appState = new AppState();

// DOM Utility Functions
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

// Section Navigation
function showSection(sectionId) {
  // Hide all sections
  $$('.section').forEach(section => {
    section.classList.remove('section--active');
  });

  // Show target section
  const targetSection = $(`#${sectionId}`);
  if (targetSection) {
    targetSection.classList.add('section--active');
    appState.currentSection = sectionId;
  }

  // Update navigation
  $$('.nav__link').forEach(link => {
    link.classList.remove('active');
  });
  const activeLink = $(`.nav__link[href="#${sectionId}"]`);
  if (activeLink) {
    activeLink.classList.add('active');
  }

  // Update progress based on section
  const sectionProgressMap = {
    'landing': 1,
    'products': 2,
    'demo': 3,
    'analytics': 4,
    'executive': 5
  };
  if (sectionProgressMap[sectionId]) {
    appState.updateProgress(sectionProgressMap[sectionId]);
  }
  
  // Initialize section-specific functionality
  if (sectionId === 'demo') {
    setTimeout(() => initializeChatDemo(), 100);
  }
}

// Country Selection Functions
function initializeCountrySelection() {
  const countryCards = $$('.country-card');
  
  countryCards.forEach(card => {
    const button = card.querySelector('.btn');
    
    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const countryKey = card.dataset.country;
      selectCountry(countryKey);
    });
    
    card.addEventListener('click', () => {
      const countryKey = card.dataset.country;
      selectCountry(countryKey);
    });
  });

  // Add event listener for continue button when DOM is ready
  document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'continueToProducts') {
      e.preventDefault();
      showSection('products');
    }
  });
}

function selectCountry(countryKey) {
  if (!applicationData.countries[countryKey]) return;

  // Update state
  appState.selectCountry(countryKey);

  // Update UI
  $$('.country-card').forEach(card => {
    card.classList.remove('selected');
  });
  
  const selectedCard = $(`.country-card[data-country="${countryKey}"]`);
  if (selectedCard) {
    selectedCard.classList.add('selected');
  }

  // Show country details
  displayCountryDetails(countryKey);
}

function displayCountryDetails(countryKey) {
  const country = applicationData.countries[countryKey];
  const detailsContainer = $('#countryDetails');
  
  if (!detailsContainer) {
    console.error('Country details container not found');
    return;
  }

  const nameElement = $('#selectedCountryName');
  const insightsElement = $('#marketInsights');
  const playersElement = $('#keyPlayers');
  const opportunitiesElement = $('#opportunities');

  if (nameElement) {
    nameElement.textContent = `${country.flag} ${country.name}`;
  }

  // Market insights
  if (insightsElement) {
    insightsElement.innerHTML = `
      <div class="stat">
        <span class="stat-label">Population</span>
        <span class="stat-value">${country.population}</span>
      </div>
      <div class="stat">
        <span class="stat-label">WhatsApp Penetration</span>
        <span class="stat-value">${country.whatsappPenetration}</span>
      </div>
      <div class="stat">
        <span class="stat-label">Banking Digital</span>
        <span class="stat-value">${country.bankingDigitalization}</span>
      </div>
      <div class="stat">
        <span class="stat-label">Mobile Money Users</span>
        <span class="stat-value">${country.mobileMoneyUsers}</span>
      </div>
      <div class="stat">
        <span class="stat-label">Avg Monthly Salary</span>
        <span class="stat-value">${country.avgMonthlySalary}</span>
      </div>
      <div class="stat">
        <span class="stat-label">Smartphone Adoption</span>
        <span class="stat-value">${country.smartphoneAdoption}</span>
      </div>
    `;
  }

  // Key players
  if (playersElement) {
    playersElement.innerHTML = country.keyPlayers.map(player => 
      `<span>${player}</span>`
    ).join('');
  }

  // Opportunities
  if (opportunitiesElement) {
    opportunitiesElement.innerHTML = country.opportunities.map(opportunity => 
      `<span>${opportunity}</span>`
    ).join('');
  }

  detailsContainer.classList.remove('hidden');
  detailsContainer.scrollIntoView({ behavior: 'smooth' });
}

// Product Configuration Functions
function initializeProductConfiguration() {
  // Product toggles
  $$('.product-toggle').forEach(toggle => {
    toggle.addEventListener('change', (e) => {
      const productKey = e.target.dataset.product;
      appState.toggleProduct(productKey);
      
      const card = e.target.closest('.product-card');
      if (e.target.checked) {
        card.classList.add('selected');
      } else {
        card.classList.remove('selected');
      }
    });
  });

  // Channel toggles
  $$('.channel-toggle').forEach(toggle => {
    toggle.addEventListener('change', (e) => {
      const channelKey = e.target.dataset.channel;
      appState.toggleChannel(channelKey);
      
      const card = e.target.closest('.channel-card');
      if (e.target.checked) {
        card.classList.add('selected');
      } else {
        card.classList.remove('selected');
      }
    });
  });

  // Add event listener for start demo button
  document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'startDemo') {
      e.preventDefault();
      if (appState.selectedProducts.size === 0) {
        alert('Please select at least one Infobip product to continue.');
        return;
      }
      showSection('demo');
    }
  });

  // Set initial channel selections
  $$('.channel-toggle[data-channel="whatsapp"], .channel-toggle[data-channel="sms"]').forEach(toggle => {
    toggle.checked = true;
    const card = toggle.closest('.channel-card');
    if (card) {
      card.classList.add('selected');
    }
  });
}

// Chat Demo Functions
function initializeChatDemo() {
  console.log('Initializing chat demo...');
  
  // Clear any existing event listeners to avoid duplicates
  const existingHandlers = document.querySelector('[data-chat-initialized]');
  if (existingHandlers) return;
  
  // Mark as initialized
  document.body.setAttribute('data-chat-initialized', 'true');
  
  // Scenario selection
  $$('.scenario-card').forEach(card => {
    card.addEventListener('click', () => {
      $$('.scenario-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      
      const scenarioId = card.dataset.scenario;
      appState.currentScenario = scenarioId;
      appState.currentStep = 0;
      startChatScenario(scenarioId);
    });
  });

  // Chat input handlers
  const chatInput = $('#chatInput');
  const sendBtn = $('#sendBtn');
  
  if (chatInput) {
    chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        sendUserMessage();
      }
    });
  }

  if (sendBtn) {
    sendBtn.addEventListener('click', (e) => {
      e.preventDefault();
      sendUserMessage();
    });
  }

  // Agent handover button
  const backToDemo = $('#backToDemo');
  if (backToDemo) {
    backToDemo.addEventListener('click', (e) => {
      e.preventDefault();
      const agentHandover = $('#agentHandover');
      const demoLayout = $('#demo .demo-layout');
      
      if (agentHandover) agentHandover.classList.add('hidden');
      if (demoLayout) demoLayout.classList.remove('hidden');
    });
  }

  // Start with first scenario
  startChatScenario(appState.currentScenario);
}

function startChatScenario(scenarioId) {
  console.log('Starting chat scenario:', scenarioId);
  
  const scenario = applicationData.bankingScenarios.find(s => s.id === scenarioId);
  if (!scenario) return;

  // Clear chat
  appState.chatMessages = [];
  appState.currentStep = 0;
  
  // Update bank name
  const bankName = $('#bankName');
  if (bankName) {
    bankName.textContent = scenario.bank;
  }
  
  // Clear chat container
  const chatContainer = $('#chatMessages');
  if (chatContainer) {
    chatContainer.innerHTML = '';
  }

  // Reset analytics
  resetAnalytics();
  
  // Start conversation after a delay
  setTimeout(() => {
    sendBotMessage(scenario.journey[0]);
  }, 1000);
}

function sendBotMessage(journeyStep) {
  console.log('Sending bot message:', journeyStep);
  
  const chatContainer = $('#chatMessages');
  if (!chatContainer) {
    console.error('Chat container not found');
    return;
  }
  
  // Show typing indicator
  showTypingIndicator();
  
  setTimeout(() => {
    hideTypingIndicator();
    
    // Create message element
    const messageElement = document.createElement('div');
    messageElement.className = 'message message--incoming fade-in';
    messageElement.style.whiteSpace = 'pre-line';
    messageElement.textContent = journeyStep.message;
    
    chatContainer.appendChild(messageElement);
    
    // Add options if available
    if (journeyStep.options && journeyStep.options.length > 0) {
      const optionsContainer = document.createElement('div');
      optionsContainer.className = 'message-options fade-in';
      
      journeyStep.options.forEach(option => {
        const button = document.createElement('button');
        button.className = 'option-button';
        button.textContent = option;
        button.addEventListener('click', (e) => {
          e.preventDefault();
          handleOptionClick(option, journeyStep);
        });
        optionsContainer.appendChild(button);
      });
      
      chatContainer.appendChild(optionsContainer);
    }
    
    // Update analytics
    updateAnalytics(journeyStep.dataCollected);
    
    // Scroll to bottom
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }, 2000);
}

function sendUserMessage() {
  const input = $('#chatInput');
  if (!input) return;
  
  const message = input.value.trim();
  
  if (!message) return;
  
  // Add user message to chat
  const chatContainer = $('#chatMessages');
  if (!chatContainer) return;
  
  const messageElement = document.createElement('div');
  messageElement.className = 'message message--outgoing fade-in';
  messageElement.textContent = message;
  
  chatContainer.appendChild(messageElement);
  
  // Clear input
  input.value = '';
  
  // Process response
  processUserResponse(message);
  
  // Scroll to bottom
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

function handleOptionClick(option, currentStep) {
  console.log('Option clicked:', option);
  
  // Add user selection to chat
  const chatContainer = $('#chatMessages');
  if (!chatContainer) return;
  
  const messageElement = document.createElement('div');
  messageElement.className = 'message message--outgoing fade-in';
  messageElement.textContent = option;
  
  chatContainer.appendChild(messageElement);
  
  // Disable option buttons
  const optionsContainers = chatContainer.querySelectorAll('.message-options');
  optionsContainers.forEach(container => {
    container.style.opacity = '0.5';
    container.style.pointerEvents = 'none';
  });
  
  // Process the selection
  processUserResponse(option);
  
  // Scroll to bottom
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

function processUserResponse(response) {
  const scenario = applicationData.bankingScenarios.find(s => s.id === appState.currentScenario);
  if (!scenario) return;
  
  // Check if we should hand over to agent
  if (response.toLowerCase().includes('agent') || response.toLowerCase().includes('speak to')) {
    setTimeout(() => {
      showAgentHandover();
    }, 1000);
    return;
  }
  
  // Move to next step
  appState.currentStep++;
  
  if (appState.currentStep < scenario.journey.length) {
    setTimeout(() => {
      sendBotMessage(scenario.journey[appState.currentStep]);
    }, 1500);
  } else {
    // End of scenario
    setTimeout(() => {
      const chatContainer = $('#chatMessages');
      if (!chatContainer) return;
      
      const finalMessage = document.createElement('div');
      finalMessage.className = 'message message--incoming fade-in';
      finalMessage.textContent = "Thank you! Your request has been processed successfully. 🎉 Is there anything else I can help you with?";
      chatContainer.appendChild(finalMessage);
      
      // Show completion options
      const optionsContainer = document.createElement('div');
      optionsContainer.className = 'message-options fade-in';
      ['Speak to Agent', 'Start New Request', 'End Conversation'].forEach(option => {
        const button = document.createElement('button');
        button.className = 'option-button';
        button.textContent = option;
        button.addEventListener('click', (e) => {
          e.preventDefault();
          if (option === 'Speak to Agent') {
            showAgentHandover();
          } else if (option === 'Start New Request') {
            // Restart current scenario
            startChatScenario(appState.currentScenario);
          }
        });
        optionsContainer.appendChild(button);
      });
      
      chatContainer.appendChild(optionsContainer);
      chatContainer.scrollTop = chatContainer.scrollHeight;
    }, 1000);
  }
}

function showTypingIndicator() {
  const chatContainer = $('#chatMessages');
  if (!chatContainer) return;
  
  const typingElement = document.createElement('div');
  typingElement.className = 'typing-indicator';
  typingElement.id = 'typingIndicator';
  typingElement.innerHTML = `
    <span>Bot is typing</span>
    <div class="typing-dots">
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    </div>
  `;
  
  chatContainer.appendChild(typingElement);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

function hideTypingIndicator() {
  const typingIndicator = $('#typingIndicator');
  if (typingIndicator) {
    typingIndicator.remove();
  }
}

function showAgentHandover() {
  const demoLayout = $('#demo .demo-layout');
  const agentHandover = $('#agentHandover');
  
  if (demoLayout) demoLayout.classList.add('hidden');
  if (agentHandover) agentHandover.classList.remove('hidden');
  
  // Populate agent interface with customer data
  populateAgentInterface();
  
  // Initialize agent chat
  initializeAgentChat();
}

function populateAgentInterface() {
  const customerProfile = $('#customerProfile');
  
  if (!customerProfile) return;
  
  // Sample customer profile data
  const profileData = {
    'Name': 'John Doe',
    'Account Type': 'Premium Savings',
    'Customer Since': '2018',
    'Last Activity': '127 days ago',
    'Account Balance': '₦45,230',
    'Credit Score': '720 (Good)',
    'Preferred Channel': 'WhatsApp',
    'Loyalty Status': 'Gold Member'
  };
  
  customerProfile.innerHTML = Object.entries(profileData).map(([key, value]) => `
    <div class="profile-item">
      <span class="data-point-label">${key}:</span>
      <span class="data-point-value">${value}</span>
    </div>
  `).join('');
  
  // Populate conversation history
  const conversationHistory = $('#conversationHistory');
  if (conversationHistory) {
    conversationHistory.innerHTML = `
      <div class="history-item">
        <strong>Previous Interactions:</strong>
        <ul style="margin: 8px 0; padding-left: 16px; font-size: 12px; color: var(--color-text-secondary);">
          <li>Account reactivation inquiry - 3 months ago</li>
          <li>Password reset request - 6 months ago</li>
          <li>Mobile banking setup - 1 year ago</li>
        </ul>
      </div>
      <div class="history-item">
        <strong>Current Session:</strong>
        <p style="font-size: 12px; color: var(--color-text-secondary); margin: 4px 0;">
          Customer engaged with reactivation campaign. High interest in cashback benefits. Ready to proceed with account reactivation.
        </p>
      </div>
    `;
  }
}

function initializeAgentChat() {
  const agentMessages = $('#agentMessages');
  
  if (!agentMessages) return;
  
  // Clear existing messages
  agentMessages.innerHTML = '';
  
  // Add initial agent message
  setTimeout(() => {
    const welcomeMessage = document.createElement('div');
    welcomeMessage.className = 'message message--incoming fade-in';
    welcomeMessage.textContent = "Hello John! I'm Sarah from Customer Success. I can see you're interested in reactivating your account with our cashback benefits. I'm here to help you complete the process. How would you like to proceed?";
    
    agentMessages.appendChild(welcomeMessage);
    agentMessages.scrollTop = agentMessages.scrollHeight;
  }, 500);
  
  // Handle agent input
  const agentInput = $('#agentInput');
  const agentSend = $('#agentSend');
  
  if (agentInput) {
    agentInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        sendAgentMessage();
      }
    });
  }
  
  if (agentSend) {
    agentSend.addEventListener('click', (e) => {
      e.preventDefault();
      sendAgentMessage();
    });
  }
}

function sendAgentMessage() {
  const input = $('#agentInput');
  const agentMessages = $('#agentMessages');
  
  if (!input || !agentMessages) return;
  
  const message = input.value.trim();
  
  if (!message) return;
  
  const messageElement = document.createElement('div');
  messageElement.className = 'message message--outgoing fade-in';
  messageElement.textContent = message;
  
  agentMessages.appendChild(messageElement);
  input.value = '';
  
  // Simulate customer response
  setTimeout(() => {
    const responses = [
      "Yes, I'd like to reactivate my account and start earning cashback immediately.",
      "Can you explain the terms and conditions for the cashback program?",
      "How long will it take to reactivate my account?",
      "I'm interested but want to understand the fees involved."
    ];
    
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    const customerMessage = document.createElement('div');
    customerMessage.className = 'message message--incoming fade-in';
    customerMessage.textContent = randomResponse;
    
    agentMessages.appendChild(customerMessage);
    agentMessages.scrollTop = agentMessages.scrollHeight;
  }, 2000);
  
  agentMessages.scrollTop = agentMessages.scrollHeight;
}

// Analytics Functions
function resetAnalytics() {
  const elements = ['#engagementScore', '#conversionProb', '#customerSegment', '#nextBestAction'];
  elements.forEach(selector => {
    const element = $(selector);
    if (element) {
      element.textContent = selector === '#engagementScore' ? '0/100' : 
                          selector === '#conversionProb' ? '0%' : '-';
    }
  });
  
  const dataPoints = $('#dataPoints');
  if (dataPoints) {
    dataPoints.innerHTML = '';
  }
}

function updateAnalytics(dataCollected) {
  if (!dataCollected) return;
  
  // Update metrics
  if (dataCollected.engagementScore) {
    const element = $('#engagementScore');
    if (element) element.textContent = dataCollected.engagementScore;
  }
  if (dataCollected.conversionProbability) {
    const element = $('#conversionProb');
    if (element) element.textContent = dataCollected.conversionProbability;
  }
  if (dataCollected.customerSegment) {
    const element = $('#customerSegment');
    if (element) element.textContent = dataCollected.customerSegment;
  }
  if (dataCollected.nextBestAction) {
    const element = $('#nextBestAction');
    if (element) element.textContent = dataCollected.nextBestAction;
  }
  
  // Update data points
  const dataPointsContainer = $('#dataPoints');
  if (dataPointsContainer) {
    dataPointsContainer.innerHTML = Object.entries(dataCollected).map(([key, value]) => `
      <div class="data-point">
        <span class="data-point-label">${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:</span>
        <span class="data-point-value">${value}</span>
      </div>
    `).join('');
  }
}

// ROI Calculator Functions
function initializeROICalculator() {
  const monthlyContactsInput = $('#monthlyContacts');
  const agentCostInput = $('#agentCost');
  const automationRateInput = $('#automationRate');
  const automationDisplay = $('#automationDisplay');
  
  if (!monthlyContactsInput || !agentCostInput || !automationRateInput) return;
  
  function updateROI() {
    const monthlyContacts = parseInt(monthlyContactsInput.value) || 0;
    const agentCost = parseFloat(agentCostInput.value) || 0;
    const automationRate = parseInt(automationRateInput.value) || 0;
    
    // Calculate ROI metrics
    const avgHandlingTime = 8; // minutes per contact
    const automatedContacts = Math.floor(monthlyContacts * (automationRate / 100));
    const hoursSaved = (automatedContacts * avgHandlingTime) / 60;
    const monthlySavings = hoursSaved * agentCost;
    const annualSavings = monthlySavings * 12;
    const infobipCost = monthlyContacts * 0.08; // Estimated cost per contact
    const annualCost = infobipCost * 12;
    const netSavings = annualSavings - annualCost;
    const roi = annualCost > 0 ? Math.round((netSavings / annualCost) * 100) : 0;
    const paybackPeriod = annualCost > 0 ? Math.round(annualCost / monthlySavings) : 0;
    
    // Update display
    if (automationDisplay) {
      automationDisplay.textContent = `${automationRate}%`;
    }
    
    const monthlySavingsEl = $('#monthlySavings');
    const annualROIEl = $('#annualROI');
    const paybackPeriodEl = $('#paybackPeriod');
    
    if (monthlySavingsEl) monthlySavingsEl.textContent = `$${Math.round(monthlySavings).toLocaleString()}`;
    if (annualROIEl) annualROIEl.textContent = `${roi}%`;
    if (paybackPeriodEl) paybackPeriodEl.textContent = `${paybackPeriod} months`;
  }
  
  // Add event listeners
  monthlyContactsInput.addEventListener('input', updateROI);
  agentCostInput.addEventListener('input', updateROI);
  automationRateInput.addEventListener('input', updateROI);
  
  // Initial calculation
  updateROI();
}

// Executive Dashboard Functions
function initializeExecutiveDashboard() {
  // Update market opportunity based on selected country
  if (appState.selectedCountry) {
    const country = applicationData.countries[appState.selectedCountry];
    const marketOpportunity = $('#marketOpportunity');
    
    if (marketOpportunity) {
      marketOpportunity.innerHTML = `
        <div class="stat-item">
          <span class="stat-number">${country.whatsappPenetration}</span>
          <span class="stat-label">WhatsApp Adoption</span>
        </div>
        <div class="stat-item">
          <span class="stat-number">${country.bankingDigitalization}</span>
          <span class="stat-label">Digital Banking</span>
        </div>
        <div class="stat-item">
          <span class="stat-number">${country.mobileMoneyUsers}</span>
          <span class="stat-label">Mobile Money Users</span>
        </div>
      `;
    }
  }
  
  // Initialize action buttons
  $$('.step-card .btn').forEach(button => {
    button.addEventListener('click', (e) => {
      e.preventDefault();
      const action = e.target.textContent;
      
      // Simulate different actions
      if (action.includes('Meeting')) {
        alert('Meeting request submitted! Our Africa banking specialist will contact you within 24 hours.');
      } else if (action.includes('Documentation')) {
        alert('Redirecting to technical documentation and sandbox environment...');
      } else if (action.includes('Pilot')) {
        alert('Pilot program request submitted! We\'ll prepare a customized pilot proposal for your organization.');
      }
    });
  });
}

// Modal Functions
function initializeModals() {
  // WhatsApp Journey Modal
  const journeyModal = $('#whatsappJourneyModal');
  const closeJourneyModal = $('#closeJourneyModal');
  
  if (closeJourneyModal) {
    closeJourneyModal.addEventListener('click', () => {
      journeyModal.classList.add('hidden');
    });
  }
  
  // Close modal on backdrop click
  if (journeyModal) {
    const backdrop = journeyModal.querySelector('.modal__backdrop');
    if (backdrop) {
      backdrop.addEventListener('click', () => {
        journeyModal.classList.add('hidden');
      });
    }
  }
}

// Initialize Navigation
function initializeNavigation() {
  $$('.nav__link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const sectionId = link.getAttribute('href').substring(1);
      showSection(sectionId);
    });
  });
}

// Main Application Initialization
document.addEventListener('DOMContentLoaded', () => {
  console.log('Initializing Infobip Africa Banking Demo...');
  
  // Initialize all components
  initializeNavigation();
  initializeCountrySelection();
  initializeProductConfiguration();
  initializeROICalculator();
  initializeExecutiveDashboard();
  initializeModals();
  
  // Initialize progress indicator
  appState.updateProgressIndicator();
  
  // Show initial section
  showSection('landing');
  
  console.log('Infobip Africa Banking Demo initialized successfully!');
});