// Infobip Africa Banking Demo Application JavaScript

class InfobipAfricaDemo {
    constructor() {
        this.currentSection = 'country-selection';
        this.selectedCountry = null;
        this.selectedProducts = ['moments', 'conversations', 'answers'];
        this.selectedChannels = ['whatsapp', 'sms', 'email', 'voice'];
        this.currentScenario = 'banking-reactivation';
        this.currentBusinessUnit = 'decision-makers';
        this.demoStep = 0;
        this.analytics = {
            messagesSent: 0,
            responseRate: 0,
            conversionProbability: 25,
            cacTracking: 0,
            engagementScore: 45
        };
        this.charts = {};
        this.scenarios = this.initializeScenarios();
        this.africaData = this.initializeAfricaData();
        
        this.init();
    }

    init() {
        this.setupNavigation();
        this.setupCountrySelection();
        this.setupProductConfiguration();
        this.setupChatbotDemos();
        this.setupMomentsInterface();
        this.setupConversationsInterface();
        this.setupBusinessUnits();
        this.setupImplementationTimeline();
        this.initializeCharts();
        
        // Load initial data
        this.loadInitialContent();
        
        console.log('Infobip Africa Banking Demo initialized! 🚀');
    }

    initializeAfricaData() {
        return {
            nigeria: {
                name: "Nigeria",
                population: "218M",
                mobilePenetration: "52%",
                smartphoneAdoption: "45%",
                bankingDigitalization: "41%",
                keyPlayers: ["GTBank", "Access Bank", "First Bank", "UBA"],
                challenges: ["Low financial inclusion", "High CAC", "Regulatory compliance"],
                opportunities: ["Mobile money growth", "Digital payments surge", "Youth demographics"],
                mobileMoneyUsers: "47M",
                internetPenetration: "51%"
            },
            kenya: {
                name: "Kenya",
                population: "56M",
                mobilePenetration: "65%",
                smartphoneAdoption: "58%",
                bankingDigitalization: "78%",
                keyPlayers: ["Safaricom M-Pesa", "Equity Bank", "KCB Bank"],
                challenges: ["Market saturation", "Competition from fintech"],
                opportunities: ["M-Pesa ecosystem", "Digital lending", "Rural expansion"],
                mobileMoneyUsers: "32M",
                internetPenetration: "87%"
            },
            southAfrica: {
                name: "South Africa",
                population: "60M",
                mobilePenetration: "73%",
                smartphoneAdoption: "71%",
                bankingDigitalization: "85%",
                keyPlayers: ["Standard Bank", "FNB", "Absa", "Nedbank"],
                challenges: ["Economic instability", "High inequality"],
                opportunities: ["Digital transformation", "Open banking", "AI adoption"],
                mobileMoneyUsers: "15M",
                internetPenetration: "70%"
            },
            ghana: {
                name: "Ghana",
                population: "33M",
                mobilePenetration: "95%",
                smartphoneAdoption: "48%",
                bankingDigitalization: "58%",
                keyPlayers: ["MTN MoMo", "Vodafone Cash", "GCB Bank"],
                challenges: ["Infrastructure gaps", "Regulatory changes"],
                opportunities: ["Mobile money leadership", "Cross-border payments"],
                mobileMoneyUsers: "18M",
                internetPenetration: "68%"
            }
        };
    }

    initializeScenarios() {
        return {
            'banking-reactivation': {
                title: "Banking Customer Reactivation",
                businessName: "Access Bank",
                avatar: "🏦",
                context: "65M customers, 84% dormant target",
                messages: [
                    {
                        type: "incoming",
                        text: "Hi John! 👋 We noticed you haven't been active lately. We've got some exciting new features waiting for you!",
                        time: "14:23",
                        options: ["See What's New", "Not Interested", "Call Me"],
                        dataPoints: {
                            customerSegment: "Warm",
                            lastActivity: "127 days ago",
                            accountBalance: "₦45,230",
                            preferredChannel: "WhatsApp"
                        }
                    },
                    {
                        type: "incoming",
                        text: "Great! Here are benefits you're missing: 💳 2% Cashback on purchases, 📱 Mobile banking rewards, 🎁 Exclusive member offers. What interests you most?",
                        time: "14:24",
                        options: ["Cashback Details", "Mobile Rewards", "Exclusive Offers"],
                        dataPoints: {
                            engagementScore: "75/100",
                            interestLevel: "High",
                            conversionProbability: "68%"
                        }
                    },
                    {
                        type: "incoming",
                        text: "Perfect! Our 2% cashback program works on all purchases, plus you get 5% on groceries and 10% on fuel. You'll also earn bonus points for every transaction. Ready to reactivate?",
                        time: "14:25",
                        options: ["Yes, Reactivate!", "Learn More", "Speak to Agent"],
                        dataPoints: {
                            engagementScore: "95/100",
                            interestLevel: "Very High",
                            conversionProbability: "85%"
                        }
                    }
                ],
                metrics: {
                    reactivationRate: "28%",
                    avgCAC: "₦1,850",
                    roi: "340%",
                    conversionTime: "3.2 days"
                }
            },
            'loan-application': {
                title: "Digital Loan Application",
                businessName: "First Bank",
                avatar: "💳",
                context: "Complete loan process via WhatsApp",
                messages: [
                    {
                        type: "incoming",
                        text: "Hello! 🏦 Ready to apply for a personal loan? I can help you get pre-approved in under 5 minutes. Let's start!",
                        time: "10:15",
                        options: ["Start Application", "Learn More", "Speak to Advisor"],
                        dataPoints: {
                            eligibilityScore: "Good",
                            creditRating: "720",
                            existingCustomer: "Yes"
                        }
                    },
                    {
                        type: "incoming",
                        text: "Excellent! Based on your profile, you're pre-qualified for up to ₦500,000 at 12% APR. How much would you like to borrow?",
                        time: "10:16",
                        options: ["₦100,000", "₦250,000", "₦500,000"],
                        dataPoints: {
                            preApprovalAmount: "₦500,000",
                            interestRate: "12% APR",
                            processingTime: "24 hours"
                        }
                    },
                    {
                        type: "incoming",
                        text: "Great choice! ₦250,000 loan approved! 🎉 Monthly payment: ₦23,456 for 12 months. Funds will be in your account within 24 hours. Proceed?",
                        time: "10:17",
                        options: ["Accept Loan", "Change Terms", "Download Contract"],
                        dataPoints: {
                            loanAmount: "₦250,000",
                            monthlyPayment: "₦23,456",
                            approvalStatus: "Approved"
                        }
                    }
                ]
            },
            'insurance-claims': {
                title: "Insurance Claims Processing",
                businessName: "AXA Mansard",
                avatar: "🛡️",
                context: "Automated claim processing",
                messages: [
                    {
                        type: "incoming",
                        text: "Hi! 👋 I'm here to help with your insurance claim. Please describe what happened and I'll guide you through the process.",
                        time: "09:30",
                        options: ["Car Accident", "Medical Emergency", "Property Damage"],
                        dataPoints: {
                            policyStatus: "Active",
                            policyNumber: "AXA123456",
                            coverage: "Comprehensive"
                        }
                    },
                    {
                        type: "incoming",
                        text: "I understand you had a car accident. I'll need some details to process your claim. Can you share photos of the damage and the police report?",
                        time: "09:31",
                        options: ["Upload Photos", "Upload Police Report", "Need Help"],
                        dataPoints: {
                            claimType: "Motor",
                            estimatedAmount: "₦85,000",
                            processingTime: "48 hours"
                        }
                    },
                    {
                        type: "incoming",
                        text: "Perfect! Documents received. 📋 Claim #CLM2024001 approved for ₦78,500. Payment will be processed within 24 hours. Anything else I can help with?",
                        time: "09:32",
                        options: ["Track Payment", "New Claim", "Speak to Agent"],
                        dataPoints: {
                            claimNumber: "CLM2024001",
                            approvedAmount: "₦78,500",
                            status: "Approved"
                        }
                    }
                ]
            }
        };
    }

    // Navigation Functions
    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.showSection(section);
            });
        });
    }

    showSection(sectionId) {
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionId}"]`)?.classList.add('active');

        // Update sections
        document.querySelectorAll('.app-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionId)?.classList.add('active');

        this.currentSection = sectionId;

        // Initialize section-specific functionality
        if (sectionId === 'chatbot-demos') {
            this.loadDemoScenario('banking-reactivation');
        } else if (sectionId === 'moments-demo') {
            this.initializeMomentsCharts();
        } else if (sectionId === 'conversations-demo') {
            this.initializeConversationsCharts();
        }
    }

    // Country Selection Functions
    setupCountrySelection() {
        const countryCards = document.querySelectorAll('.country-card');
        countryCards.forEach(card => {
            card.addEventListener('click', () => {
                const country = card.dataset.country;
                this.selectCountry(country);
            });
        });

        // Setup parameter sliders
        this.setupParameterSliders();
    }

    selectCountry(country) {
        // Remove previous selection
        document.querySelectorAll('.country-card').forEach(card => {
            card.classList.remove('selected');
        });

        // Add selection to clicked card
        document.querySelector(`[data-country="${country}"]`).classList.add('selected');
        
        this.selectedCountry = country;
        
        // Show company parameters
        const parametersSection = document.getElementById('company-parameters');
        if (parametersSection) {
            parametersSection.style.display = 'block';
            parametersSection.scrollIntoView({ behavior: 'smooth' });
        }

        this.showNotification(`${this.africaData[country].name} selected! Configure your bank parameters below.`);
    }

    setupParameterSliders() {
        const sliders = document.querySelectorAll('.range-slider');
        sliders.forEach(slider => {
            slider.addEventListener('input', (e) => {
                this.updateSliderValue(slider.id, e.target.value);
            });
        });
    }

    updateSliderValue(sliderId, value) {
        const displayElement = document.getElementById(`${sliderId}-value`);
        if (displayElement) {
            let displayValue = value;
            
            if (sliderId === 'total-customers') {
                displayValue = this.formatNumber(parseInt(value));
            } else if (sliderId.includes('rate') || sliderId.includes('reduction') || sliderId.includes('reactivation')) {
                displayValue = value + '%';
            }
            
            displayElement.textContent = displayValue;
        }
    }

    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    proceedToConfiguration() {
        if (!this.selectedCountry) {
            this.showNotification('Please select a country first!', 'error');
            return;
        }
        this.showSection('product-config');
    }

    // Product Configuration Functions
    setupProductConfiguration() {
        const productToggles = document.querySelectorAll('.product-card input[type="checkbox"]');
        productToggles.forEach(toggle => {
            toggle.addEventListener('change', (e) => {
                const productId = e.target.id.replace('-toggle', '');
                this.toggleProduct(productId, e.target.checked);
            });
        });
    }

    toggleProduct(productId, enabled) {
        if (enabled && !this.selectedProducts.includes(productId)) {
            this.selectedProducts.push(productId);
        } else if (!enabled) {
            this.selectedProducts = this.selectedProducts.filter(p => p !== productId);
        }
    }

    startDemoExperience() {
        if (this.selectedProducts.length === 0) {
            this.showNotification('Please select at least one product!', 'error');
            return;
        }
        this.showSection('chatbot-demos');
    }

    // Chatbot Demo Functions
    setupChatbotDemos() {
        const scenarioCards = document.querySelectorAll('.scenario-card');
        scenarioCards.forEach(card => {
            card.addEventListener('click', () => {
                const scenario = card.dataset.scenario;
                this.loadDemoScenario(scenario);
            });
        });
    }

    loadDemoScenario(scenarioId) {
        // Update scenario selection
        document.querySelectorAll('.scenario-card').forEach(card => {
            card.classList.remove('active');
        });
        document.querySelector(`[data-scenario="${scenarioId}"]`)?.classList.add('active');

        this.currentScenario = scenarioId;
        const scenario = this.scenarios[scenarioId];
        
        if (!scenario) return;

        // Update business info
        const businessName = document.getElementById('demo-business-name');
        const businessAvatar = document.getElementById('demo-business-avatar');
        
        if (businessName) businessName.textContent = scenario.businessName;
        if (businessAvatar) businessAvatar.textContent = scenario.avatar;

        // Reset demo state
        this.demoStep = 0;
        this.analytics = {
            messagesSent: 0,
            responseRate: 0,
            conversionProbability: 25,
            cacTracking: 0,
            engagementScore: 45
        };

        // Clear chat and start demo
        this.clearDemoChat();
        this.updateAnalyticsDashboard();
        
        // Start the demo after a brief delay
        setTimeout(() => {
            this.sendDemoMessage();
        }, 1000);
    }

    clearDemoChat() {
        const chatMessages = document.getElementById('demo-chat-messages');
        if (chatMessages) {
            chatMessages.innerHTML = '';
        }

        const responseOptions = document.getElementById('response-options');
        if (responseOptions) {
            responseOptions.innerHTML = '';
        }

        this.hideTyping();
    }

    sendDemoMessage() {
        const scenario = this.scenarios[this.currentScenario];
        if (!scenario || this.demoStep >= scenario.messages.length) return;

        const message = scenario.messages[this.demoStep];
        
        // Show typing indicator
        this.showTyping();
        
        setTimeout(() => {
            this.hideTyping();
            this.addDemoMessage(message);
            this.updateAnalyticsFromMessage(message);
            this.demoStep++;
        }, 2000);
    }

    addDemoMessage(messageData) {
        const chatMessages = document.getElementById('demo-chat-messages');
        if (!chatMessages) return;

        const messageEl = document.createElement('div');
        messageEl.className = `chat-message ${messageData.type}`;

        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';

        const messageText = document.createElement('div');
        messageText.className = 'message-text';
        messageText.textContent = messageData.text;

        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        messageTime.textContent = messageData.time;

        messageContent.appendChild(messageText);
        messageContent.appendChild(messageTime);
        messageEl.appendChild(messageContent);

        chatMessages.appendChild(messageEl);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Add response options if available
        if (messageData.options && messageData.type === 'incoming') {
            setTimeout(() => {
                this.showResponseOptions(messageData.options);
            }, 500);
        }

        // Animate message appearance
        messageEl.style.opacity = '0';
        messageEl.style.transform = 'translateY(20px)';
        setTimeout(() => {
            messageEl.style.transition = 'all 0.3s ease';
            messageEl.style.opacity = '1';
            messageEl.style.transform = 'translateY(0)';
        }, 100);
    }

    showResponseOptions(options) {
        const responseOptions = document.getElementById('response-options');
        if (!responseOptions) return;

        responseOptions.innerHTML = '';

        options.forEach(option => {
            const button = document.createElement('button');
            button.textContent = option;
            button.addEventListener('click', () => {
                this.handleUserResponse(option);
            });
            responseOptions.appendChild(button);
        });
    }

    handleUserResponse(response) {
        // Add user message
        const userMessage = {
            type: 'outgoing',
            text: response,
            time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
        };

        this.addDemoMessage(userMessage);
        
        // Clear response options
        const responseOptions = document.getElementById('response-options');
        if (responseOptions) {
            responseOptions.innerHTML = '';
        }

        // Update analytics
        this.analytics.responseRate = Math.min(100, this.analytics.responseRate + 25);
        this.analytics.messagesSent++;
        
        if (this.demoStep < this.scenarios[this.currentScenario].messages.length) {
            setTimeout(() => {
                this.sendDemoMessage();
            }, 1000);
        } else {
            // Demo completed
            this.analytics.conversionProbability = 85;
            this.analytics.engagementScore = 95;
            this.updateAnalyticsDashboard();
            this.showNotification('Demo completed! Customer successfully engaged. 🎉');
        }
        
        this.updateAnalyticsDashboard();
    }

    updateAnalyticsFromMessage(messageData) {
        this.analytics.messagesSent++;
        
        if (messageData.dataPoints) {
            // Update specific data points
            Object.entries(messageData.dataPoints).forEach(([key, value]) => {
                const element = document.getElementById(key.replace(/([A-Z])/g, '-$1').toLowerCase());
                if (element) {
                    element.textContent = value;
                }
            });

            // Update engagement score
            if (messageData.dataPoints.engagementScore) {
                this.analytics.engagementScore = parseInt(messageData.dataPoints.engagementScore.split('/')[0]);
            }

            // Update conversion probability
            if (messageData.dataPoints.conversionProbability) {
                this.analytics.conversionProbability = parseInt(messageData.dataPoints.conversionProbability.replace('%', ''));
            }
        }

        // Update CAC tracking based on message count
        this.analytics.cacTracking = this.analytics.messagesSent * 150; // ₦150 per message

        this.updateAnalyticsDashboard();
    }

    updateAnalyticsDashboard() {
        const updates = {
            'messages-sent': this.analytics.messagesSent,
            'response-rate': `${this.analytics.responseRate}%`,
            'conversion-probability': `${this.analytics.conversionProbability}%`,
            'cac-tracking': `₦${this.analytics.cacTracking}`,
            'engagement-score': `${this.analytics.engagementScore}/100`
        };

        Object.entries(updates).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) element.textContent = value;
        });

        // Update engagement chart if it exists
        if (this.charts.engagementChart) {
            this.updateEngagementChart();
        }
    }

    showTyping() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.classList.remove('hidden');
        }
    }

    hideTyping() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.classList.add('hidden');
        }
    }

    simulateAgentTakeover() {
        this.showNotification('Simulating agent takeover... Redirecting to Conversations interface.');
        setTimeout(() => {
            this.showSection('conversations-demo');
        }, 1500);
    }

    // Moments Interface Functions
    setupMomentsInterface() {
        const momentsNavLinks = document.querySelectorAll('.moments-nav-link');
        momentsNavLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const tab = link.dataset.momentsTab;
                this.showMomentsTab(tab);
            });
        });
    }

    showMomentsTab(tabId) {
        // Update navigation
        document.querySelectorAll('.moments-nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-moments-tab="${tabId}"]`)?.classList.add('active');

        // Update tabs
        document.querySelectorAll('.moments-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.getElementById(`moments-${tabId}`)?.classList.add('active');

        // Initialize tab-specific content
        if (tabId === 'dashboard') {
            this.initializeMomentsCharts();
        } else if (tabId === 'analytics') {
            this.initializePerformanceChart();
        }
    }

    initializeMomentsCharts() {
        // Initialize segment chart
        if (!this.charts.segmentChart) {
            this.initializeSegmentChart();
        }
    }

    initializeSegmentChart() {
        const ctx = document.getElementById('segment-chart');
        if (!ctx) return;

        this.charts.segmentChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Cold Customers', 'Warm Customers', 'Hot Customers'],
                datasets: [{
                    data: [45, 35, 20],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    initializePerformanceChart() {
        const ctx = document.getElementById('performance-chart');
        if (!ctx || this.charts.performanceChart) return;

        const data = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [
                {
                    label: 'WhatsApp Campaigns',
                    data: [28, 35, 42, 38, 45, 52],
                    backgroundColor: '#1FB8CD',
                    borderColor: '#1FB8CD'
                },
                {
                    label: 'SMS Campaigns',
                    data: [12, 15, 18, 16, 20, 22],
                    backgroundColor: '#FFC185',
                    borderColor: '#FFC185'
                },
                {
                    label: 'Email Campaigns',
                    data: [8, 9, 12, 10, 13, 15],
                    backgroundColor: '#B4413C',
                    borderColor: '#B4413C'
                }
            ]
        };

        this.charts.performanceChart = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Conversion Rate (%)'
                        }
                    }
                }
            }
        });
    }

    // Conversations Interface Functions
    setupConversationsInterface() {
        // Setup conversation switching
        const conversationItems = document.querySelectorAll('.conversation-item');
        conversationItems.forEach(item => {
            item.addEventListener('click', () => {
                this.switchConversation(item.dataset.conversation);
            });
        });

        // Setup dark mode toggle
        const darkModeToggle = document.querySelector('.dark-mode-toggle');
        if (darkModeToggle) {
            darkModeToggle.addEventListener('click', () => {
                this.toggleDarkMode();
            });
        }
    }

    switchConversation(conversationId) {
        // Update active conversation
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-conversation="${conversationId}"]`)?.classList.add('active');

        // Update conversation content based on ID
        this.loadConversationContent(conversationId);
    }

    loadConversationContent(conversationId) {
        const conversations = {
            '1': {
                customerName: 'John Adebayo',
                messages: [
                    { type: 'customer', text: 'Hi, I received a WhatsApp message about reactivating my account. Can you help me understand the offers?', time: '14:20' },
                    { type: 'agent', text: 'Hello John! I\'d be happy to help you with account reactivation. I can see you\'re a premium customer with us. Let me walk you through our current offers.', time: '14:21' }
                ]
            },
            '2': {
                customerName: 'Grace Okafor',
                messages: [
                    { type: 'customer', text: 'I applied for a loan last week. What\'s the status?', time: '14:15' },
                    { type: 'agent', text: 'Hi Grace! Let me check your application status. I can see your loan for ₦150,000 is currently under review. You should hear back within 24 hours.', time: '14:16' }
                ]
            }
        };

        const conversation = conversations[conversationId];
        if (!conversation) return;

        // Update customer info
        const customerInfo = document.querySelector('.customer-info h4');
        if (customerInfo) {
            customerInfo.textContent = conversation.customerName;
        }

        // Update messages
        const chatMessages = document.getElementById('agent-chat-messages');
        if (chatMessages) {
            chatMessages.innerHTML = '';
            conversation.messages.forEach(msg => {
                this.addAgentMessage(msg);
            });
        }
    }

    addAgentMessage(messageData) {
        const chatMessages = document.getElementById('agent-chat-messages');
        if (!chatMessages) return;

        const messageEl = document.createElement('div');
        messageEl.className = `chat-message ${messageData.type}`;

        messageEl.innerHTML = `
            <div class="message-content">
                <div class="message-text">${messageData.text}</div>
                <div class="message-time">${messageData.time}</div>
            </div>
        `;

        chatMessages.appendChild(messageEl);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
        this.showNotification('Dark mode toggled! This would switch the entire interface theme.');
    }

    initializeConversationsCharts() {
        // Initialize queue chart
        const queueCtx = document.getElementById('queue-chart');
        if (queueCtx && !this.charts.queueChart) {
            this.charts.queueChart = new Chart(queueCtx, {
                type: 'bar',
                data: {
                    labels: ['WhatsApp', 'Voice', 'Email', 'Chat'],
                    datasets: [{
                        label: 'Queue Length',
                        data: [8, 3, 1, 2],
                        backgroundColor: ['#25D366', '#3b82f6', '#f59e0b', '#8b5cf6']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }

    // Business Units Functions
    setupBusinessUnits() {
        const unitTabs = document.querySelectorAll('.unit-tab');
        unitTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const unit = tab.dataset.unit;
                this.showBusinessUnit(unit);
            });
        });
    }

    showBusinessUnit(unitId) {
        // Update navigation
        document.querySelectorAll('.unit-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-unit="${unitId}"]`)?.classList.add('active');

        // Update content
        document.querySelectorAll('.unit-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(unitId)?.classList.add('active');

        this.currentBusinessUnit = unitId;

        // Initialize unit-specific content
        if (unitId === 'c-level') {
            this.initializeCLevelCharts();
        }
    }

    initializeCLevelCharts() {
        const ctx = document.getElementById('impact-chart');
        if (!ctx || this.charts.impactChart) return;

        this.charts.impactChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Revenue Growth', 'Cost Reduction', 'Customer Satisfaction', 'Operational Efficiency'],
                datasets: [{
                    label: 'Business Impact (%)',
                    data: [28, 35, 18, 67],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Impact Percentage (%)'
                        }
                    }
                }
            }
        });
    }

    // Implementation Functions
    setupImplementationTimeline() {
        // Add hover effects and interactions for phase cards
        const phaseCards = document.querySelectorAll('.phase-card');
        phaseCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                this.highlightPhase(card.dataset.phase);
            });
            card.addEventListener('mouseleave', () => {
                this.unhighlightPhases();
            });
        });
    }

    highlightPhase(phaseNumber) {
        document.querySelectorAll('.phase-card').forEach(card => {
            if (card.dataset.phase !== phaseNumber) {
                card.style.opacity = '0.6';
            }
        });
    }

    unhighlightPhases() {
        document.querySelectorAll('.phase-card').forEach(card => {
            card.style.opacity = '1';
        });
    }

    // Chart Initialization
    initializeCharts() {
        // Initialize engagement chart
        setTimeout(() => {
            this.initializeEngagementChart();
        }, 500);
    }

    initializeEngagementChart() {
        const ctx = document.getElementById('engagement-chart');
        if (!ctx) return;

        this.charts.engagementChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['0s', '30s', '60s', '90s', '120s'],
                datasets: [{
                    label: 'Engagement Score',
                    data: [45, 55, 70, 85, 95],
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    borderColor: '#1FB8CD',
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    updateEngagementChart() {
        if (!this.charts.engagementChart) return;

        const newData = [45, 55, 70, Math.min(100, this.analytics.engagementScore), Math.min(100, this.analytics.engagementScore + 5)];
        this.charts.engagementChart.data.datasets[0].data = newData;
        this.charts.engagementChart.update();
    }

    // Content Loading
    loadInitialContent() {
        // Load default country selection state
        setTimeout(() => {
            this.selectCountry('nigeria');
        }, 1000);
    }

    // Utility Functions
    contactSales() {
        this.showNotification('Connecting you to Infobip sales team... 📞 In a real environment, this would open a contact form or initiate a call.');
    }

    downloadImplementationGuide() {
        this.showNotification('Downloading implementation guide... 📄 This would generate and download a PDF with detailed implementation steps.');
    }

    requestPOC() {
        this.showNotification('Proof of Concept request submitted! 🎯 Our team will contact you within 24 hours to set up your custom POC.');
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Style the notification
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'error' ? '#dc2626' : '#FC6323'};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 10000;
            font-size: 14px;
            font-weight: 500;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            animation: slideInRight 0.3s ease;
            max-width: 350px;
            word-wrap: break-word;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }, 4000);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add required CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        .dark-mode .agent-interface {
            background: #1f2937;
        }
        
        .dark-mode .conversation-messages {
            background: #111827;
        }
        
        .dark-mode .chat-message.agent .message-content {
            background: #374151;
        }
    `;
    document.head.appendChild(style);

    // Initialize the demo application
    const app = new InfobipAfricaDemo();
    
    // Make functions globally available for HTML onclick handlers
    window.selectCountry = (country) => app.selectCountry(country);
    window.proceedToConfiguration = () => app.proceedToConfiguration();
    window.startDemoExperience = () => app.startDemoExperience();
    window.loadDemoScenario = (scenario) => app.loadDemoScenario(scenario);
    window.simulateAgentTakeover = () => app.simulateAgentTakeover();
    window.showBusinessUnit = (unit) => app.showBusinessUnit(unit);
    window.contactSales = () => app.contactSales();
    window.downloadImplementationGuide = () => app.downloadImplementationGuide();
    window.requestPOC = () => app.requestPOC();
    window.toggleDarkMode = () => app.toggleDarkMode();
    window.showSection = (section) => app.showSection(section);
    window.updateSliderValue = (id, value) => app.updateSliderValue(id, value);

    // Make app globally available for debugging
    window.infobipAfricaDemo = app;
    
    console.log('Infobip Africa Banking Demo Application loaded successfully! 🌍🏦');
    console.log('Features: Country Selection, Product Config, Interactive Chatbots, Moments, Conversations, Business Units, Implementation');
    console.log('Try selecting a country and exploring the different demo sections!');
});

// Handle responsive navigation for mobile
document.addEventListener('DOMContentLoaded', () => {
    const handleResize = () => {
        const nav = document.querySelector('.main-nav');
        if (window.innerWidth <= 768) {
            // Mobile view - could add mobile menu here
            if (nav) {
                nav.style.display = 'none';
            }
        } else {
            // Desktop view
            if (nav) {
                nav.style.display = 'flex';
            }
        }
    };

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial check
});

// Export for potential module use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = InfobipAfricaDemo;
}